
#import <UIKit/UIKit.h>

@interface CleverTapTrackedViewController : UIViewController

@property(readwrite, nonatomic, copy) NSString *screenName;

@end
